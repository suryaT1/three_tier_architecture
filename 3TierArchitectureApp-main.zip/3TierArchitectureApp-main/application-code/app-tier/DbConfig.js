module.exports = Object.freeze({
    DB_HOST : 'database-1.c380a08uukyc.ap-south-1.rds.amazonaws.com',
    DB_USER : 'admin',
    DB_PWD : 'kastro2025',
    DB_DATABASE : 'webappdb'
});
